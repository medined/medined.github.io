package com.affy.client;

import com.affy.remote.SimpleBean;
import com.affy.home.SimpleBeanHome;
import com.affy.util.SimpleBeanUtil;

class SimpleBeanClient {

	public static void main(String[] args) {
		System.setProperty("java.naming.factory.initial", "org.jnp.interfaces.NamingContextFactory");
		System.setProperty("java.naming.provider.url", "localhost:1099");
	
		try {
			SimpleBeanHome home = SimpleBeanUtil.getHome();

			SimpleBean sb = home.create();
			String pKey = (String)sb.getPrimaryKey();
			System.out.println("ID: " + pKey);

			SimpleBean b = home.findByPrimaryKey(pKey);
			System.out.println("ID: " + b.getPrimaryKey());

			System.out.println("Done.");
		} catch(Exception e) {
			System.out.println(e.toString());
		}
	}
}
