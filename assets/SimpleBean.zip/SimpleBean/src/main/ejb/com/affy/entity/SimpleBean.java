package com.affy.entity;

import java.rmi.RemoteException;
import javax.ejb.*;
import com.affy.util.SimpleBeanUtil;

/**
 * @ejb.bean name="SimpleBean" type="CMP" cmp-version="2.x" jndi-name="ejb/affy/SimpleBean" primkey-field="pKey"
 * @ejb.util generate="physical"
 */
public abstract class SimpleBean implements EntityBean {

	public EntityContext mContext;

	/** @ejb.persistence */
	public abstract String getPKey();
	public abstract void setPKey(String pKey);

	/** @ejb.create-method view-type="remote" */
	public String ejbCreate() throws EJBException, CreateException {
		this.setPKey(SimpleBeanUtil.generateGUID(this));
		return this.getPKey();
	}

	public void ejbPostCreate() { /* do nothing */ }
	public void ejbRemove() throws RemoveException, EJBException, RemoteException {}
	public void ejbActivate() throws EJBException, RemoteException {}
	public void ejbPassivate() throws EJBException, RemoteException {}
	public void ejbLoad() throws EJBException, RemoteException {}
	public void ejbStore() throws EJBException, RemoteException {}
	public void setEntityContext(EntityContext lContext) { mContext = lContext; }
	public void unsetEntityContext() { mContext = null; }
}