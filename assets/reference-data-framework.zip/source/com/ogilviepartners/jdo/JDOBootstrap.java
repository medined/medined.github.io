package com.ogilviepartners.jdo;

import java.io.*;
import javax.jdo.PersistenceManagerFactory;
import javax.jdo.JDOHelper;
import java.util.Properties;
import java.util.Enumeration;
import java.util.ArrayList;
import java.util.Collection;

public class JDOBootstrap
{
	private Properties p = new Properties();
	private PersistenceManagerFactory pmf;

	private String[] jdoPropertyNames = { 
			"javax.jdo.PersistenceManagerFactoryClass",
			"javax.jdo.option.Optimistic",
			"javax.jdo.option.RetainValues",
			"javax.jdo.option.IgnoreCache",
			"javax.jdo.option.NontransactionalRead",
			"javax.jdo.option.NontransactionalWrite",
			"javax.jdo.option.ConnectionUserName",
			"javax.jdo.option.ConnectionPassword",
			"javax.jdo.option.ConnectionURL",
			"javax.jdo.option.ConnectionFactoryName",
			"javax.jdo.option.ConnectionFactory2Name",
			"javax.jdo.option.ConnectionDriverName",
			"javax.jdo.option.Multithreaded"};

	
	public JDOBootstrap() { 
  	// try classpath
    InputStream propStream = getClass().getResourceAsStream ("/kodo.properties");
    if (propStream == null)
    {
       // try local
       propStream = getClass().getResourceAsStream ("kodo.properties");
       if (propStream == null)
       {
          System.out.println ("Could not load properties from file \"kodo.properties\"");
          System.exit (1);
       }
    }
    try
    {
       p.load (propStream);
    }
    catch (java.io.IOException ex)
    {
       ex.printStackTrace ();
       System.exit (1);
    }
		
	}
		
	private void instantiatePersistenceManagerFactory() {
		pmf = JDOHelper.getPersistenceManagerFactory(p);			
	}
		
	public void listJDOProperties() {
		Collection c = new ArrayList();
		for (int i=0; i<jdoPropertyNames.length; i++) {
			c.add(jdoPropertyNames[i]);
		}

		System.out.println("Listing standard JDO properties");	
		for (Enumeration e = p.propertyNames(); e.hasMoreElements(); ) {
		  String s = (String) e.nextElement();
			if (c.contains(s)) System.out.println(s + "=" + p.getProperty(s));
		}
		System.out.println("Listing non-standard JDO properties");	
		for (Enumeration e = p.propertyNames(); e.hasMoreElements(); ) {
		  String s = (String) e.nextElement();
			if (!(c.contains(s))) System.out.println(s + "=" + p.getProperty(s));		
		}
		System.out.println();
	}
	
	public void listVendorProperties() {

	  if (pmf == null) {
			System.out.println("Instatiating PersistenceManagerFactory");
			instantiatePersistenceManagerFactory();
			System.out.println();
		}
		System.out.println("Listing JDO Vendor properties");
		System.out.println("VendorName=" + pmf.getProperties().getProperty("VendorName"));
		System.out.println("VersionNumber=" + pmf.getProperties().getProperty("VersionNumber"));		
		System.out.println();
	}
	
  public PersistenceManagerFactory getPersistenceManagerFactory() {
	  if (pmf == null) instantiatePersistenceManagerFactory();
		return pmf;
  }
}
